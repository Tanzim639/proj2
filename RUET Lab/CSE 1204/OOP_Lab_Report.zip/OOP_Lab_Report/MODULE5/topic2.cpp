#include<iostream>
using namespace std;

class Circuit {
private:
    int real;
    int img;

public:
    // Constructor
    Circuit(int r, int i) : real(r), img(i) {}

    // Operator overloading for parallel impedance calculation
    Circuit operator||(const Circuit& other) const {
        int newReal = (real * other.real + img * other.img) / (real + other.real);
        int newImg = (real * other.img - img * other.real) / (real + other.real);
        return Circuit(newReal, newImg);
    }

    // Display method
    void display() const {
        cout << "Real: " << real << ", Imaginary: " << img << endl;
    }
};

int main() {
    // Initialize impedances
    Circuit z1(3, 4);
    Circuit z2(4, -3);
    Circuit z3(0, 6);

    // Input voltage
    Circuit v_in(100, 50);

    // Calculate equivalent impedance for parallel connection
    Circuit z_parallel = z1 || z2 || z3;

    // Calculate current using Ohm's Law (I = V / Z)
    Circuit current = v_in / z_parallel;

    // Display the current
    cout << "Current in the circuit: ";
    current.display();

    return 0;
}
